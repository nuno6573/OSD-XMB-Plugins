EN
MOD for POPSLoader By El_isra - REV 5

- Added support for images for games, they must respect a certain format:

	+ Extension ".PNG" 

	+ Have a transparency mask (if it doesn't have one, the image won't be displayed) 

	+ Preferably with dimensions less than (120x120) (RAM problems)

	+ they must go in the "ART" folder with the same name as the VCD file.
	Example: if the game is called "Mortal Kombat.VCD"
		 the image must be called "Mortal Kombat.PNG"

- There is a problem with the release of RAM memory if the images are very large or you have many games and the images are overloaded, the program will restart.

- The directories of the images, both of games, and the default ones can be edited in the code so that it searches in other places.

- added "START" to exit to PS2 menu and "R3" button to exit to "mass/XEBPLUS/XEBPLUS_XMAS.elf"

- Added options to return to Browser.
	NOTE: "you must edit the code to add the directory you want, it is preset to XEBPLUS" 
	(You can also add any directory to a .ELF executable)





ES
MOD de POPSLoader By El_isra - REV 5

- Se agreg  soporte de im genes para los juegos, deben respetar cierto formato:

	+ Extensi n ".PNG" 

	+ Tener mascara de trasparencia (si no la tiene no se muestra la imagen) 

	+ De preferencia con dimensiones inferiores a (120x120) (problemas de RAM)

	+ deben ir en la carpeta "ART" con el mismo nombre que el archivo VCD.
	Ejemplo: si el juego se llama "Mortal Kombat.VCD"
		 la imagen se debe llamar "Mortal Kombat.PNG"

- Existe un problema con la liberaci n de memoria RAM si las im genes son muy grandes o se tiene muchos juegos y se sobrecargan las 	im genes el programa se reiniciara.

- Los directorios de las im genes, tanto de juegos, como las de por defecto puede editarse en el c digo para que busque en otros lugares.

- se agreg  "START" para salir al men  de PS2 y el bot n de "R3" para salir a "mass/XEBPLUS/XEBPLUS_XMAS.elf"

- Se agregaron opciones para volver al Browser.
	NOTA: "se debe editar el c digo para agregar el directorio que quieran, est  preestablecido en XEBPLUS" 
	(Tambi n puede agregarse cualquier directorio a un ejecutable .ELF)




PT
POPSLoader MOD by El_isra - REV 5

- Adicionado suporte de imagem para jogos, estes devem respeitar um determinado formato:

	+ Extens o ".PNG" 

	+ Ter m scara de transpar ncia (se n o tiver, a imagem n o ser  mostrada) 

	+ De prefer ncia com dimens es inferiores a (120x120) (problemas de RAM)

	+ devem ir para a pasta "ART" com o mesmo nome do ficheiro VCD.
	Exemplo: se o jogo se chamar "Mortal Kombat.VCD"
		 a imagem deveria chamar-se "Mortal Kombat.PNG"

- Existe um problema de liberta  o de RAM se as imagens forem demasiado grandes ou se tiver muitos jogos e as imagens estiverem 	sobrecarregadas, o programa ser  reiniciado.

- Os diret rios de imagens, tanto do jogo como standard, podem ser editados no c digo para que este pesquise noutros locais.

- adicionado "START" para sair do menu PS2 e bot o "R3" para sair para "mass/XEBPLUS/XEBPLUS_XMAS.elf"

- Adicionadas op  es para voltar ao Navegador.
	NOTA: "deve editar o c digo para adicionar o diret rio pretendido, est  pr -estabelecido no XEBPLUS" 
	(Qualquer diret rio tamb m pode ser adicionado a um execut vel . ELF)

