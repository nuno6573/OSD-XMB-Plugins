-- timer.lua
Timer = {}

function Timer.new()
  return {startTime = os.clock()}
end

function Timer.getTime(timer)
  return (os.clock() - timer.startTime) * 1000 -- return time in milliseconds
end

function Timer.reset(timer)
  timer.startTime = os.clock()
end

return Timer